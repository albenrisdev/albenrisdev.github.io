#!/usr/bin/env python3
# Lumina Chronos for Linux: the timer page (web/, the same files as the Windows app) in a GTK 4 window
# with WebKitGTK. Everything it needs (Python, PyGObject, GTK 4, libadwaita, WebKitGTK 6) is in the
# GNOME runtime the Flatpak uses, so there is nothing to compile.
#
# What the window does for the page, as the Windows app (Windows/LuminaChronos/MainForm.cs) does:
# - serves web/ at lumina-chronos://app/ (never change that address: settings are stored per address);
# - gives the page `window.chrome.webview.postMessage`, the WebView2 bridge app.js already uses, and
#   handles its plain string messages: "notify\n<text>" (a session ended while minimised: a desktop
#   notification) and "keepAwake:on" / "keepAwake:off" (a session is running: the screen stays on);
# - calls `window.__appPause(true/false)` when the window is minimised or restored, and sets
#   `window.__lcLanguage` to the desktop's language before the page loads;
# - shows the page title ("24:59 · Lumina Chronos" while running) as the window title;
# - F11 or Alt+Enter: full screen. Links to other sites open in the user's browser.
#
# Run it from the project folder without installing: python3 src/lumina-chronos.py
# LC_DEBUG=1 turns on the web inspector (right-click > Inspect Element).
import json
import os
import re
import sys

import gi

gi.require_version("Gdk", "4.0")
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
gi.require_version("WebKit", "6.0")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk, WebKit  # noqa: E402

APP_ID = "uk.co.albenrisdev.LuminaChronos"
APP_TITLE = "Lumina Chronos"
SCHEME = "lumina-chronos"
HOST = "app"
START_URL = f"{SCHEME}://{HOST}/index.html"
PAGE_BACKGROUND = "#191A1F"
MIN_SIZE = (400, 640)  # as on Windows
DEFAULT_SIZE = (480, 800)
NOTIFICATION_ID = "session-complete"
DEBUG = os.environ.get("LC_DEBUG") == "1"

MIME_TYPES = {
    ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".json": "application/json",
    ".webmanifest": "application/manifest+json", ".png": "image/png", ".svg": "image/svg+xml",
    ".wav": "audio/wav", ".ttf": "font/ttf", ".woff2": "font/woff2", ".ico": "image/x-icon",
}

# A user script that runs before the page's own scripts.
BRIDGE = """
window.chrome = window.chrome || {};
window.chrome.webview = {
  postMessage: function (message) { window.webkit.messageHandlers.native.postMessage(String(message)); },
};
window.__lcLanguage = %s;
"""


def find_web_folder():
    """web/ next to this script when run from the project, share/lumina-chronos/web when installed."""
    here = os.path.dirname(os.path.realpath(__file__))
    candidates = [os.environ.get("LC_WEB_DIR"),
                  os.path.join(here, "..", "share", "lumina-chronos", "web"),
                  os.path.join(here, "..", "web")]
    for folder in candidates:
        if folder and os.path.isfile(os.path.join(folder, "index.html")):
            return os.path.realpath(folder)
    return None


def ui_language():
    """The desktop's language as a tag like "de-DE" (from LANGUAGE / LC_ALL / LC_MESSAGES / LANG)."""
    for name in GLib.get_language_names():
        tag = name.split(".")[0].split("@")[0].replace("_", "-")
        if tag in ("C", "POSIX"):
            continue
        if re.fullmatch(r"[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*", tag):
            return tag
    return "en"


def is_app_url(uri):
    try:
        parsed = GLib.Uri.parse(uri, GLib.UriFlags.NONE)
    except GLib.Error:
        return False
    return parsed.get_scheme() == SCHEME and parsed.get_host() == HOST


def state_folder(kind):
    """Where the app keeps its data. In the Flatpak these are under ~/.var/app/<app id>/."""
    base = {"data": GLib.get_user_data_dir, "cache": GLib.get_user_cache_dir,
            "config": GLib.get_user_config_dir}[kind]()
    return os.path.join(base, "lumina-chronos")


class MainWindow(Adw.ApplicationWindow):
    def __init__(self, app, web_folder, session):
        super().__init__(application=app, title=APP_TITLE)
        self.app = app
        self.web_folder = web_folder
        self.messages = []  # every message from the page, for tools/smoke_test.py
        self._minimized = None
        self._inhibit_cookie = 0
        self._fullscreen_key_held = False
        self._surface = None

        self.add_css_class("lc-window")
        self.set_size_request(*MIN_SIZE)
        self._restore_size()

        # The page
        content = WebKit.UserContentManager()
        content.add_script(WebKit.UserScript.new(
            BRIDGE % json.dumps(ui_language()), WebKit.UserContentInjectedFrames.TOP_FRAME,
            WebKit.UserScriptInjectionTime.START, None, None))
        content.register_script_message_handler("native", None)
        content.connect("script-message-received::native", self._on_page_message)

        self.view = WebKit.WebView(network_session=session, user_content_manager=content)
        background = Gdk.RGBA()
        background.parse(PAGE_BACKGROUND)
        self.view.set_background_color(background)
        settings = self.view.get_settings()
        settings.set_media_playback_requires_user_gesture(False)  # the session-end sounds
        # Store links (target=_blank) and window.open both end in _on_decide_policy, which sends them
        # to the browser; no second window is ever made.
        settings.set_javascript_can_open_windows_automatically(True)
        settings.set_enable_back_forward_navigation_gestures(False)
        settings.set_enable_developer_extras(DEBUG)
        self.view.set_vexpand(True)
        self.view.connect("decide-policy", self._on_decide_policy)
        self.view.connect("notify::title", self._on_title_changed)
        self.view.connect("load-changed", self._on_load_changed)
        self.view.connect("web-process-terminated", lambda view, _reason: view.reload())
        self.view.connect("context-menu", lambda *_: not DEBUG)

        # A flat header bar in the page colour; hidden in full screen.
        self.toolbar = Adw.ToolbarView()
        self.toolbar.add_top_bar(Adw.HeaderBar())
        self.toolbar.set_top_bar_style(Adw.ToolbarStyle.FLAT)
        self.toolbar.set_content(self.view)
        self.set_content(self.toolbar)
        self.connect("notify::fullscreened", self._on_fullscreen_changed)

        # F11 / Alt+Enter, caught before the page sees them.
        keys = Gtk.EventControllerKey()
        keys.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        keys.connect("key-pressed", self._on_key_pressed)
        keys.connect("key-released", self._on_key_released)
        self.add_controller(keys)

        self.connect("realize", self._on_realize)
        self.connect("close-request", self._on_close_request)
        self.view.load_uri(START_URL)

    # ------------------------------------------------------------------ navigation
    def _on_decide_policy(self, _view, decision, kind):
        if kind not in (WebKit.PolicyDecisionType.NAVIGATION_ACTION,
                        WebKit.PolicyDecisionType.NEW_WINDOW_ACTION):
            return False
        uri = decision.get_navigation_action().get_request().get_uri()
        if kind == WebKit.PolicyDecisionType.NAVIGATION_ACTION and is_app_url(uri):
            return False  # the timer itself (also #settings etc.)
        decision.ignore()  # never a second window or another site in this one
        self.open_in_browser(uri)
        return True

    def open_in_browser(self, uri):
        if is_app_url(uri) or not re.match(r"https?://", uri or "", re.IGNORECASE):
            return
        try:
            Gtk.UriLauncher.new(uri).launch(self, None, None, None)
        except GLib.Error as error:
            print(f"Could not open {uri}: {error.message}", file=sys.stderr)

    def _on_title_changed(self, view, _param):
        title = view.get_title()
        self.set_title(title if title and not title.startswith(SCHEME + ":") else APP_TITLE)

    def _on_load_changed(self, view, event):
        if event == WebKit.LoadEvent.FINISHED:
            self._tell_page_minimized(force=True)
            view.grab_focus()  # so Space works straight away

    # ------------------------------------------------------------------ messages from the page
    def _on_page_message(self, _content, value):
        if not is_app_url(self.view.get_uri() or ""):
            return
        message = value.to_string() if value.is_string() else None
        if message is None:
            return
        self.messages.append(message)
        if message.startswith("notify\n"):
            self.show_notification(message[len("notify\n"):])
        elif message in ("keepAwake:on", "keepAwake:off"):
            self.set_keep_awake(message == "keepAwake:on")

    def show_notification(self, body):
        notification = Gio.Notification.new(APP_TITLE)
        notification.set_body(body[:250])
        notification.set_default_action("app.restore")  # clicking it brings the window back
        notification.set_priority(Gio.NotificationPriority.HIGH)
        self.app.send_notification(NOTIFICATION_ID, notification)

    def set_keep_awake(self, on):
        if on and not self._inhibit_cookie:
            self._inhibit_cookie = self.app.inhibit(
                self, Gtk.ApplicationInhibitFlags.IDLE, "A focus session is running")  # screen stays on
        elif not on and self._inhibit_cookie:
            self.app.uninhibit(self._inhibit_cookie)
            self._inhibit_cookie = 0

    # ------------------------------------------------------------------ minimising
    def _on_realize(self, _window):
        self._surface = self.get_surface()
        self._surface.connect("notify::state", lambda *_: self._tell_page_minimized())

    def is_minimized(self):
        if self._surface is None:
            return False
        state = self._surface.get_state()
        # X11 and some Wayland desktops report MINIMIZED. Wayland has no "minimised" state, so on
        # GNOME and others the closest is SUSPENDED: the window can't be seen (minimised, on another
        # workspace or fully covered).
        hidden = Gdk.ToplevelState.MINIMIZED | getattr(Gdk.ToplevelState, "SUSPENDED", 0)
        return bool(state & hidden)

    def _tell_page_minimized(self, force=False):
        minimized = self.is_minimized()
        if minimized == self._minimized and not force:
            return
        self._minimized = minimized
        if not minimized:
            self.app.withdraw_notification(NOTIFICATION_ID)
        self.run_script("window.__appPause && window.__appPause(%s)" % ("true" if minimized else "false"))

    def run_script(self, script):
        self.view.evaluate_javascript(script, -1, None, None, None, None, None)

    # ------------------------------------------------------------------ full screen
    def _on_key_pressed(self, _controller, keyval, _keycode, state):
        alt_enter = (keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter)
                     and state & Gdk.ModifierType.ALT_MASK)
        if keyval != Gdk.KEY_F11 and not alt_enter:
            return False
        if not self._fullscreen_key_held:  # ignore key repeat
            self._fullscreen_key_held = True
            self.toggle_fullscreen()
        return True

    def _on_key_released(self, _controller, keyval, _keycode, _state):
        if keyval in (Gdk.KEY_F11, Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_Alt_L, Gdk.KEY_Alt_R):
            self._fullscreen_key_held = False

    def toggle_fullscreen(self):
        if self.is_fullscreen():
            self.unfullscreen()
        else:
            self.fullscreen()

    def _on_fullscreen_changed(self, *_):
        self.toolbar.set_reveal_top_bars(not self.is_fullscreen())

    # ------------------------------------------------------------------ window size
    @property
    def _size_file(self):
        return os.path.join(state_folder("config"), "window.json")

    def _restore_size(self):
        width, height = DEFAULT_SIZE
        maximized = False
        try:
            with open(self._size_file, encoding="utf-8") as f:
                saved = json.load(f)
            width = max(MIN_SIZE[0], int(saved.get("width", width)))
            height = max(MIN_SIZE[1], int(saved.get("height", height)))
            maximized = bool(saved.get("maximized", False))
        except (OSError, ValueError, TypeError, AttributeError):
            pass
        self.set_default_size(width, height)
        if maximized:
            self.maximize()

    def _on_close_request(self, _window):
        self.set_keep_awake(False)
        width, height = self.get_default_size()
        try:
            os.makedirs(os.path.dirname(self._size_file), exist_ok=True)
            with open(self._size_file, "w", encoding="utf-8") as f:
                json.dump({"width": width, "height": height, "maximized": self.is_maximized()}, f)
        except OSError:
            pass
        return False


class LuminaChronos(Adw.Application):
    window_class = MainWindow

    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        self.window = None
        self.web_folder = None
        GLib.set_application_name(APP_TITLE)

    def do_startup(self):
        Adw.Application.do_startup(self)
        self.get_style_manager().set_color_scheme(Adw.ColorScheme.FORCE_DARK)
        css = Gtk.CssProvider()
        css.load_from_string(".lc-window, .lc-window headerbar { background-color: %s; }" % PAGE_BACKGROUND)
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        for name, callback in (("restore", self._on_restore), ("quit", self._on_quit)):
            action = Gio.SimpleAction.new(name, None)
            action.connect("activate", callback)
            self.add_action(action)
        self.set_accels_for_action("app.quit", ["<Control>q"])
        self.set_accels_for_action("window.close", ["<Control>w"])

        self.web_folder = find_web_folder()
        context = WebKit.WebContext.get_default()
        context.register_uri_scheme(SCHEME, self._serve)
        security = context.get_security_manager()
        security.register_uri_scheme_as_secure(SCHEME)
        security.register_uri_scheme_as_cors_enabled(SCHEME)
        context.set_preferred_languages([ui_language()])
        self.session = WebKit.NetworkSession.new(
            os.path.join(state_folder("data"), "web"), os.path.join(state_folder("cache"), "web"))

    def do_activate(self):
        if self.window is None:
            if self.web_folder is None:
                self._show_missing_files()
                return
            self.window = self.window_class(self, self.web_folder, self.session)
            self.window.connect("destroy", lambda *_: setattr(self, "window", None))
        self.window.present()

    def _on_restore(self, *_):
        self.activate()

    def _on_quit(self, *_):
        if self.window is not None:
            self.window.close()
        self.quit()

    def _show_missing_files(self):
        print("The timer files are missing (web/index.html). Reinstall Lumina Chronos.", file=sys.stderr)
        dialog = Adw.AlertDialog.new(APP_TITLE, "Lumina Chronos could not start: its files are missing. "
                                                "Please reinstall it.")
        dialog.add_response("close", "Close")
        window = Adw.ApplicationWindow(application=self)
        dialog.connect("response", lambda *_: window.close())
        window.present()
        dialog.present(window)

    # lumina-chronos://app/<path> -> web/<path>
    def _serve(self, request):
        root = self.web_folder
        path = GLib.Uri.unescape_string(request.get_path() or "/", None) or "/"
        relative = os.path.normpath(path.lstrip("/")) if path.strip("/") else "index.html"
        full = os.path.realpath(os.path.join(root, relative)) if root else ""
        if (not root or not is_app_url(request.get_uri()) or not full.startswith(root + os.sep)
                or not os.path.isfile(full)):
            request.finish_error(GLib.Error.new_literal(
                Gio.io_error_quark(), "Not found: " + path, int(Gio.IOErrorEnum.NOT_FOUND)))
            return
        stream = Gio.File.new_for_path(full).read(None)
        response = WebKit.URISchemeResponse.new(stream, os.path.getsize(full))
        response.set_content_type(MIME_TYPES.get(os.path.splitext(full)[1].lower(),
                                                 "application/octet-stream"))
        request.finish_with_response(response)


def main(argv=None):
    return LuminaChronos().run(sys.argv if argv is None else argv)


if __name__ == "__main__":
    sys.exit(main())
